package org.example;
//Interface Segregation Principle
public interface Payment {
    int addDeliveryCharge();
}